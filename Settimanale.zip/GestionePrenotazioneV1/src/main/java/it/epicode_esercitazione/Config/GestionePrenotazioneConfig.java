package it.epicode_esercitazione.Config;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import it.epicode_esercitazione.Repository.PalazzoRepository;
import it.epicode_esercitazione.Repository.PostazioneRepository;
import it.epicode_esercitazione.Repository.PrenotazioneRepository;
import it.epicode_esercitazione.Repository.UtenteRepository;
import it.epicode_esercitazione.models.Disponibile;
import it.epicode_esercitazione.models.Palazzo;
import it.epicode_esercitazione.models.Postazione;
import it.epicode_esercitazione.models.Prenotazione;
import it.epicode_esercitazione.models.Utente;

@Service
public class GestionePrenotazioneConfig {
	@Autowired
	private PalazzoRepository palazzoRepository;
	@Autowired
	private UtenteRepository utenteRepository;
	@Autowired
	private PostazioneRepository postazioneRepository;
	@Autowired
	private PrenotazioneRepository prenotazioneRepository;
	
	public void addUser(Utente user) {
        utenteRepository.save(user);
    }
	//Aggiungo un palazzo
	 public void addBuilding(Palazzo building) {
	        palazzoRepository.save(building);
	    }
	 
	 //Recupero il palazzo usando il suo id
	 public Palazzo getBuildingById(Long id) {
		 return palazzoRepository.findById(id).get();
	 }
	 //Aggiungo una postazione ad un palazzo nel main usando questo metodo
	 public void addWorkstation(Postazione postazione) {
	       postazioneRepository.save(postazione);
	      
	 }
	 public Utente getUtenteById(String username) {
		 return utenteRepository.findById(username).get();
	 }
	 public Postazione findPostazioneById(Long id) {
		return postazioneRepository.findById(id).get();
	 }
	 //Aggiunta Prenotazione ad un utente
	 public void aggiungiPrenotazione(Prenotazione prenotazione) {
		    prenotazioneRepository.save(prenotazione);
		}
	 //Modifica disponibilita di una postazione
	 public void modificaDisponibilitaPostazione(Long id, Disponibile disponibilita) {
			Postazione postazione = postazioneRepository.findById(id).orElse(null);
			if (postazione == null) {
				throw new RuntimeException("Postazione non trovata");
			}
			postazione.setDisponibile(Disponibile.NO);;
			postazioneRepository.save(postazione);
		}
}
