package it.epicode_esercitazione;

import java.time.LocalDate;
import java.time.LocalDateTime;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import it.epicode_esercitazione.Config.GestionePrenotazioneConfig;
import it.epicode_esercitazione.models.Disponibile;
import it.epicode_esercitazione.models.Palazzo;
import it.epicode_esercitazione.models.Postazione;
import it.epicode_esercitazione.models.Prenotazione;
import it.epicode_esercitazione.models.TipoPostazione;
import it.epicode_esercitazione.models.Utente;

@SpringBootApplication
public class GestionePrenotazioneV1Application {

	public static void main(String[] args) {
		ApplicationContext context = SpringApplication.run(GestionePrenotazioneV1Application.class, args);
		GestionePrenotazioneConfig app = context.getBean(GestionePrenotazioneConfig.class);
		//Aggiuta Utente
		Utente u = new Utente("Mario Rossi", "Pippo", "mario.rossi@gmail.com");
		boolean addUser = false;
		if(addUser) {
			app.addUser(u);	
		}
		//Aggiunta Palazzo
		Palazzo p = new Palazzo();
		p.setCitta("Milano");
		p.setIndirizzo("Via San Siro, 20");
		p.setNome("Gaming Center");
		boolean addPalazzo = false;
		if(addPalazzo) {
			app.addBuilding(p);
		}
		//Aggiunta Postazione
		Palazzo p1 = app.getBuildingById(1L);
		Postazione post = new Postazione();
		post.setMaxOccupanti(50);
		post.setTipo(TipoPostazione.OPEN_SPACE);
		post.setDescrizione("Sala Conferenza");
		post.setDisponibile(Disponibile.SI);
		post.setPalazzo(p1);
		boolean addPostazione = false;
		if(addPostazione) {
			app.addWorkstation(post);			
		}
		//Aggiunta prenotazione ad utente
		Postazione p2 = app.findPostazioneById(1l);
		Utente u3 = app.getUtenteById("Mario Rossi");
		Prenotazione preno = new Prenotazione();
		preno.setDate(LocalDate.now());
		preno.setPostazione(p2);
		preno.setUtente(u);
		boolean addPrenotazione = true;
		if(addPrenotazione) {
			app.aggiungiPrenotazione(preno);
			app.modificaDisponibilitaPostazione(p2.getId(), Disponibile.NO);
		}
	}

}
