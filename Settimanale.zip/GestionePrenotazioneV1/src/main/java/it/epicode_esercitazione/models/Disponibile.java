package it.epicode_esercitazione.models;

public enum Disponibile {
	SI,
	NO
}
