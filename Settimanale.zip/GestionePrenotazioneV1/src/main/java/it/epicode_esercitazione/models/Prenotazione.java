package it.epicode_esercitazione.models;


import java.time.LocalDate;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "prenotazioni")
@Getter
@Setter
public class Prenotazione {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private LocalDate date;
	@ManyToOne
	private Postazione postazione;
	@ManyToOne
	private Utente utente;
	
	public Prenotazione() {}

    public Prenotazione(Long id, LocalDate date, Postazione postazione, Utente utente) {
        this.id = id;
        this.date = date;
        this.postazione = postazione;
        this.utente = utente;
    }
}
