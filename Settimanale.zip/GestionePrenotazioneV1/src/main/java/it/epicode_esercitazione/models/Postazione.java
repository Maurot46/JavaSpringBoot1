package it.epicode_esercitazione.models;


import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "postazioni")
@Getter
@Setter
public class Postazione {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String descrizione;
    @Enumerated(EnumType.STRING)
    private TipoPostazione tipo;
    @Enumerated(EnumType.STRING)
    private Disponibile disponibile;
    private int maxOccupanti;
    @ManyToOne
    @JoinColumn(name = "palazzo_id")
    private Palazzo palazzo;
    
    public Postazione() {
    	
    }

	public Postazione(Long id, String descrizione, TipoPostazione tipo, int maxOccupanti, Palazzo palazzo) {
		this.id = id;
		this.descrizione = descrizione;
		this.tipo = tipo;
		this.maxOccupanti = maxOccupanti;
		this.palazzo = palazzo;
	}
}
