package it.epicode_esercitazione.models;

public enum TipoPostazione {
	PRIVATO, 
	OPEN_SPACE, 
	SALA_RIUNIONI
}
