package it.epicode_esercitazione.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import it.epicode_esercitazione.models.Prenotazione;

public interface PrenotazioneRepository extends JpaRepository<Prenotazione, Long>{

}
