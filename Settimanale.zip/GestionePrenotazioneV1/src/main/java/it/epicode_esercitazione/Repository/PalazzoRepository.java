package it.epicode_esercitazione.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import it.epicode_esercitazione.models.Palazzo;

public interface PalazzoRepository extends JpaRepository<Palazzo, Long>{

}
